<?php

function ainext_enqueue_style() {
    wp_enqueue_style("parent-style",get_parent_theme_file_uri("/style.css"));
}
add_action( 'wp_enqueue_scripts', 'ainext_enqueue_style' );
?>