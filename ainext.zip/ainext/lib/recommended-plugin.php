<?php
/**
 * Include the TGM_Plugin_Activation class.
 */

require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'ainext_register_required_plugins' );

if ( ! function_exists( 'ainext_register_required_plugins' ) ) {
	function ainext_register_required_plugins() {

		$plugins = array(
			
			// AiNext Toolkit
			array(
				'name'               => esc_html__('AiNext Toolkit', 'ainext'),
				'slug'               => 'ainext-toolkit',
				'source'             => get_template_directory() . '/lib/plugins/ainext-toolkit.zip', 
				'required'           => true,
			),

			// Elemantor Page Builder Pro
			array(
				'name'               => esc_html__('Elementor Pro', 'ainext'),
				'slug'               => 'elementor-pro',
				'source'             => 'https://demo.alhikmahsoft.com/tools/elementor-pro.zip',

				'required'           => false,
			),

			array(
				'name'               => esc_html__('Elementor Page Builder', 'ainext'),
				'slug'               => 'elementor',
				'required'           => true,
			),

			// Advanced Custom Fields Pro
			array(
				'name'               => esc_html__('Advanced Custom Fields Pro', 'ainext'),
				'slug'               => 'advanced-custom-fields-pro',
				'source'             => 'https://demo.alhikmahsoft.com/tools/advanced-custom-fields-pro.zip',
				'required'           => false,
			),

			// WooCommerce
			array(
				'name'      => esc_html__('WooCommerce', 'ainext'),
				'slug'      => 'woocommerce',
				'required'  => false,
			),

			array(
				'name'      => esc_html__('Contact Form 7', 'ainext'),
				'slug'      => 'contact-form-7',
				'required'  => false,
			),
			array(
				'name'      => esc_html__('AI Engine', 'ainext'),
				'slug'      => 'ai-engine',
				'required'  => false,
			),
			array(
               'name'       => esc_html__( 'AHS Demo Importer', 'ainext' ),
               'slug'       => 'ahs-demo-importer',
			   'source'             => 'https://demo.alhikmahsoft.com/tools/ahs-demo-importer.zip',
               'required'   => false,
           ),
		);

		$config = array(
			'id'           => 'tgmpa',
			'default_path' => '',
			'menu'         => 'tgmpa-install-plugins',
			'parent_slug'  => 'themes.php',
			'capability'   => 'edit_theme_options',
			'has_notices'  => true, 
			'dismissable'  => true, 
			'dismiss_msg'  => '',   
			'is_automatic' => false, 
			'message'      => '',                      
		);
		tgmpa( $plugins, $config );
	}
}