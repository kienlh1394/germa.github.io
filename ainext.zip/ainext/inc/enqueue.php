<?php
/**
 * Enqueue scripts and styles.
 */
if ( ! function_exists( 'ainext_scripts' ) ) :

	function ainext_scripts() {

		wp_enqueue_style( 'ainext-style', get_stylesheet_uri() );

		wp_enqueue_style( 'bootstrap', 			    AINEXT_CSS . '/bootstrap.min.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'owl-carousel', 			AINEXT_CSS . '/owl.carousel.min.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'owl-theme-default', 		AINEXT_CSS . '/owl.theme.default.min.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'magnific-popup', 		AINEXT_CSS . '/magnific-popup.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'aos', 			        AINEXT_CSS . '/aos.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'remixicon',              AINEXT_CSS . '/remixicon.min.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'flaticon',              	AINEXT_CSS . '/flaticon.css', null, AINEXT_VERSION );

		wp_enqueue_style( 'ainext-woocommerce', 	AINEXT_CSS . '/ainext-woocommerce.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'ainext-main', 	        AINEXT_CSS . '/ainext-main.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'ainext-blog', 	        AINEXT_CSS . '/ainext-blog.css', null, AINEXT_VERSION );
		wp_enqueue_style( 'ainext-responsive', 	    AINEXT_CSS . '/ainext-responsive.css', null, AINEXT_VERSION );
		
		wp_enqueue_script( 'bootstrap-bundle', 	    AINEXT_JS . '/bootstrap.bundle.min.js', array('jquery'), AINEXT_VERSION );
		wp_enqueue_script( 'aos', 	                AINEXT_JS . '/aos.js', array('jquery'), AINEXT_VERSION );
		wp_enqueue_script( 'owl-carousel', 	        AINEXT_JS . '/owl.carousel.min.js', array('jquery'), AINEXT_VERSION );
		wp_enqueue_script( 'magnific-popup', 	    AINEXT_JS . '/magnific-popup.min.js', array('jquery'), AINEXT_VERSION );
		wp_enqueue_script( 'ajaxchimp', 	        AINEXT_JS . '/ajaxchimp.min.js', array('jquery'),AINEXT_JS );
		wp_enqueue_script( 'ainext-main', 			AINEXT_JS . '/ainext-main.js', array('jquery'), AINEXT_VERSION );
		
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
	
endif;
add_action( 'wp_enqueue_scripts', 'ainext_scripts' );
