<?php
/**
 * Register custom style.
 */

if ( ! function_exists( 'ainext_custom_style' ) ) {
    function ainext_custom_style(){
        
        $custom_style ='';
        global $ainext_opt;

        // Navbar Style 2
        if( isset ($ainext_opt['nav_s2_bg']['url']) ):
            if( $ainext_opt['nav_s2_bg']['url'] != '' ):
                $custom_style .="
                .dental-tourism-navbar .main-navbar .navbar .navbar-brand::before {
                    background-image: url(" . esc_url( $ainext_opt['nav_s2_bg']['url'] ) . ");
                }
                ";
            else :
                $custom_style .="
                .dental-tourism-navbar .main-navbar .navbar .navbar-brand {
                    color: #000;
                }
                .top-dental-tourism-information.with-left {
                    margin-left: 0;
                }
                ";
            endif;
        endif;

        // Custom Css
        if( isset($ainext_opt['css_code'] ) && !empty($ainext_opt['css_code']) ):
            $custom_style .= $ainext_opt['css_code'];
        endif;

        if( !is_user_logged_in() ){ 
            $custom_style .=' #wpadminbar {
                display: none;
            }';
        }

        wp_add_inline_style('ainext-main', $custom_style);

        // Custom Js
        $custom_script ='';
        if( isset($ainext_opt['js_code'] )){
            $custom_script .= $ainext_opt['js_code'];
        }
        
        wp_add_inline_script( 'ainext-main', $custom_script );
    }
}
add_action( 'wp_enqueue_scripts', 'ainext_custom_style' );