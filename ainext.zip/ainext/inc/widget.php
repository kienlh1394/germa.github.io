<?php
/**
 * Register Theme Widget
 * @package AiNext
*/

// Theme Sidebar
if ( ! function_exists( 'ainext_widgets_init' ) ) {
    function ainext_widgets_init() {
        global $ainext_opt;

        register_sidebar( array(
            'name'          => esc_html__( 'Blog Sidebar', 'ainext' ),
            'id'            => 'article-sidebar',
            'description'   => esc_html__( 'Add widgets here.', 'ainext' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ) );
        // Shop Sidebar
        if ( class_exists( 'WooCommerce' ) ){
            register_sidebar( array( 
                'name'          => esc_html__( 'Shop Sidebar', 'ainext' ),
                'id'            => 'shop',
                'description'   => esc_html__( 'Add widgets here.', 'ainext' ),
                'before_widget' => '<div class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<h3 class="widget-title">',
                'after_title'   => '</h3>',
            ) );
        }
        // Footer Sidebar
        $footer_column = isset( $ainext_opt['footer_column']) ? $ainext_opt['footer_column'] : '-lg-4';
        register_sidebar( array(
            'name'          => esc_html__( 'Footer Widgets', 'ainext' ),
            'id'            => 'footer_widgets',
            'description'   => esc_html__( 'Add widgets here.', 'ainext' ),
            'before_widget' => '<div class="single-footer-widget col'.$footer_column.' %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget_title">',
            'after_title'   => '</h3>',
        ) );

    }
}
add_action( 'widgets_init', 'ainext_widgets_init' );