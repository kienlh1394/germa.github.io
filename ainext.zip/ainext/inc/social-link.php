<?php 
/**
 * Social Link
 * @package WordPress
 * @subpackage AiNext
*/ 

if ( ! function_exists( 'ainext_social_link' ) ) :
    function ainext_social_link(){ 
        global $ainext_opt;

        if( isset( $ainext_opt['ainext_social_target'] ) ) {
            $target = $ainext_opt['ainext_social_target'];
        } else {
            $target = '_blank';
        } ?>
        
        <?php if (isset( $ainext_opt['facebook_url'] ) && $ainext_opt['facebook_url'] ) { ?>
            <li><a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url( $ainext_opt['facebook_url'] ); ?>"> <i class="ri-facebook-line"></i></a></li>
        <?php  } ?>
        
        <?php if (isset( $ainext_opt['twitter_url'] ) && $ainext_opt['twitter_url'] ) { ?>
            <li><a target="<?php echo esc_attr( $target ); ?>" href="<?php  echo esc_url( $ainext_opt['twitter_url'] );?>" > <i class="ri-twitter-fill"></i></a></li>
        <?php  } ?>

        <?php if (isset( $ainext_opt['instagram_url'] ) && $ainext_opt['instagram_url'] ) { ?>
            <li><a target="<?php echo esc_attr( $target ); ?>" href="<?php  echo esc_url( $ainext_opt['instagram_url'] ); ?>"> <i class="ri-instagram-line"></i></a></li>
        <?php  } ?>

        <?php if (isset($ainext_opt['linkedin_url'] ) && $ainext_opt['linkedin_url'] ) { ?>
            <li><a target="<?php echo esc_attr( $target ); ?>" href="<?php  echo esc_url( $ainext_opt['linkedin_url'] );?>" > <i class="ri-linkedin-line"></i></a></li>
        <?php  } ?>

        <?php if (isset( $ainext_opt['pinterest_url'] ) && $ainext_opt['pinterest_url'] ) { ?>
            <li><a target="<?php echo esc_attr( $target ); ?>" href="<?php echo esc_url( $ainext_opt['pinterest_url'] );?>" > <i class="ri-pinterest-line"></i></a></li>
        <?php  } ?>

        <?php if (isset( $ainext_opt['whatsapp_url'] ) && $ainext_opt['whatsapp_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr( $target ); ?>" href="<?php echo esc_url( $ainext_opt['whatsapp_url'] );?>" > <i class="ri-whatsapp-line"></i></a>
        </li>
        <?php  } ?>

        <?php if (isset( $ainext_opt['tiktok_url'] ) && $ainext_opt['tiktok_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr( $target ); ?>" href="<?php echo esc_url( $ainext_opt['tiktok_url'] );?>" > <i class="ri-tiktok-line"></i></a>
        </li>
        <?php  } ?>

        <?php if (isset( $ainext_opt['dribbble_url'] ) && $ainext_opt['dribbble_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr( $target ); ?>" href="<?php echo esc_url( $ainext_opt['dribbble_url'] );?>" > <i class="ri-dribbble-line"></i></a>
        </li>
        <?php } ?>

        <?php if (isset( $ainext_opt['tumblr_url'] ) && $ainext_opt['tumblr_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr( $target ); ?>" href="<?php  echo esc_url( $ainext_opt['tumblr_url'] );?>" > <i class="ri-tumblr-line"></i></a>
        </li>
        <?php } ?>

        <?php if (isset($ainext_opt['youtube_url'] ) && $ainext_opt['youtube_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($ainext_opt['youtube_url']);?>" > <i class="ri-youtube-line"></i></a>
        </li>
        <?php  } ?>

        <?php if (isset($ainext_opt['flickr_url'] ) && $ainext_opt['flickr_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($ainext_opt['flickr_url']);?>" > <i class="ri-flickr-line"></i></a>
        </li>
        <?php } ?>

        <?php if (isset($ainext_opt['behance_url'] ) && $ainext_opt['behance_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($ainext_opt['behance_url']);?>" > <i class="ri-behance-line"></i></a>
        </li>
        <?php } ?>

        <?php if (isset($ainext_opt['github_url'] ) &&  $ainext_opt['github_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($ainext_opt['github_url']);?>" > <i class="ri-github-line"></i></a>
        </li>
        <?php } ?>

        <?php if (isset($ainext_opt['skype_url'] ) && $ainext_opt['skype_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($ainext_opt['skype_url']);?>" > <i class="ri-skype-line"></i></a>
        </li>
        <?php } ?>

        <?php if (isset($ainext_opt['rss_url'] ) && $ainext_opt['rss_url'] ) { ?>
        <li>
            <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($ainext_opt['rss_url']);?>" > <i class="ri-rss-line"></i></a>
        </li>
        <?php } ?>

    <?php
    }
endif; ?>