<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package AiNext
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function ainext_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'article-sidebar' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'ainext_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function ainext_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'ainext_pingback_header' );

 /*
 * Pagination
 */
if ( ! function_exists( 'ainext_pagination' ) ) :
    function ainext_pagination() {
    ?>
        <div class="pagination-area">
			<div class="nav-links">
				<?php echo paginate_links( array(
					'format' => '?paged=%#%',
					'prev_text' => '<i class="ri-arrow-left-s-line"></i>',
					'next_text' => '<i class="ri-arrow-right-s-line"></i>',
					)
				) ?>
			</div>
		</div>
    <?php
    }
endif;

/**
 * If page edited by elementor
 */
if ( ! function_exists( 'ainext_is_elementor' ) ) :
	function ainext_is_elementor(){
		if ( function_exists( 'elementor_fail_php_version' ) ):
			global $post;
			return \Elementor\Plugin::$instance->documents->get( $post->ID )->is_built_with_elementor();
		endif;
	}
endif;

/**
 * AiNext Main Logo
*/
if ( ! function_exists( 'ainext_main_logo' ) ) :
	function ainext_main_logo(){
		global $ainext_opt;
		// ainext Logo
		if ( isset( $ainext_opt['main_logo']['url'] ) && $ainext_opt['main_logo']['url'] !='' ) :
			$main_logo = $ainext_opt['main_logo']['url'];
		else :
			$main_logo = 'null';
		endif;
		?>
			<?php if ( $main_logo != 'null' ) : ?>
				<img src="<?php echo esc_url( $main_logo ); ?>" alt="<?php bloginfo( 'name' ); ?>">
			<?php else : ?>
				<h2><?php bloginfo( 'name' ); ?> </h2>
			<?php endif; ?>
		<?php
	}
endif;

/**
 * AiNext Footer Logo
 */
if ( ! function_exists( 'footer_logo' ) ) :
	function footer_logo(){
		global $ainext_opt;
		// ainext Logo
		if ( isset( $ainext_opt['footer_logo']['url']) && $ainext_opt['footer_logo']['url'] !='' ) :
			$ainext_logo = $ainext_opt['footer_logo']['url'];
		else :
			$ainext_logo = 'null';
		endif;
		?>
			<?php if ( $ainext_logo != 'null' ) : ?>
				<img src="<?php echo esc_url( $ainext_logo ); ?>" alt="<?php bloginfo( 'name' ); ?>">
			<?php else : ?>
				<h2><?php bloginfo( 'name' ); ?> </h2>
			<?php endif; ?>
		<?php
	}
endif;

/**
 * AiNext Mobile Logo
*/
if ( ! function_exists( 'ainext_mobile_logo' ) ) :
	function ainext_mobile_logo(){
		global $ainext_opt;
		// AiNext Logo
		if ( isset( $ainext_opt['ainext_mobile_logo']['url']) && $ainext_opt['ainext_mobile_logo']['url'] !='' ) :
			$ainext_logo = $ainext_opt['ainext_mobile_logo']['url'];
		else :
			$ainext_logo = 'null';
		endif;
		?>
			<?php if ( $ainext_logo != 'null' ) : ?>
				<img src="<?php echo esc_url($ainext_logo); ?>" alt="<?php bloginfo( 'name' ); ?>">
			<?php else : ?>
				<h2><?php bloginfo( 'name' ); ?> </h2>
			<?php endif; ?>
		<?php
	}
endif;

/**
 * Estimated Reading Time
 */
if ( ! function_exists( 'ainext_reading_time' ) ) :
	function ainext_reading_time() {
		global $post;
		$thecontent  = get_post_field( 'post_content', $post->ID );
		$words 		 = str_word_count( strip_tags( $thecontent ) );
		$readingtime = ceil( $words / 200 );
		$output 	 = $readingtime;
		return $output;
	}
endif;

// Custom Service Search Result
if ( ! function_exists( 'ainext_template_chooser' ) ) {
	function ainext_template_chooser($template)   
	{    
		global $wp_query;   
		$post_type = get_query_var('post_type');   
		if( $wp_query->is_search && $post_type == 'service')   
		{
			if (!empty($post_type)){
				return locate_template('search-service.php');  //  redirect to search-service.php
			} else {
				return locate_template('content-none.php'); 
			}
		}
		elseif( $wp_query->is_search && $post_type == 'doctor')   
		{
			if (!empty($post_type)){
				return locate_template('search-doctor.php');  //  redirect to search-service.php
			} else {
				return locate_template('content-none.php'); 
			}
		}
		return $template;
	}
}
add_filter('template_include', 'ainext_template_chooser');

//Single Services Sidebar Title Active Class
if ( ! function_exists( 'ainext_if_current' ) ) {
	function ainext_if_current($active) {
		global $wp_query,$post;
		$current    = $wp_query->get_queried_object_id();
		$post_id    = $post->ID;
		if($current==$post_id){echo esc_attr($active, 'ainext');}
	}
}