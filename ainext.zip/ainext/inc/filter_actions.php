<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 * @package AiNext
 */

/**
 * Filter the categories archive widget to add a span around post count
 */
if ( ! function_exists( 'ainext_cat_count_span' ) ) {
	function ainext_cat_count_span( $links ) {
		$links = str_replace( '</a> (', '</a><span class="post-count">(', $links );
		$links = str_replace( ')', ')</span>', $links );
		return $links;
	}
}
add_filter( 'wp_list_categories', 'ainext_cat_count_span' );

/**
 * Filter the archives widget to add a span around post count
 */
if ( ! function_exists( 'ainext_archive_count_span' ) ) {
	function ainext_archive_count_span( $links ) {
		$links = str_replace( '</a>&nbsp;(', '</a><span class="post-count">(', $links );
		$links = str_replace( ')', ')</span>', $links );
		return $links;
	}
}
add_filter( 'get_archives_link', 'ainext_archive_count_span' );

/**
 * Excerpt more text
 */
if ( ! function_exists( 'ainext_excerpt_more' ) ) :
	function ainext_excerpt_more( $more ) {
		return ' ';
	}
endif;
add_filter('excerpt_more', 'ainext_excerpt_more');

/**
 * Menu Registration
*/
if ( ! function_exists( 'ainext_register_primary_menus' ) ) :
	function ainext_register_primary_menus(){
		register_nav_menus(
			array(
				'primary' 		=> esc_html__('Primary Menu', 'ainext'),
			)
		);
	}
endif;
add_action('init', 'ainext_register_primary_menus');

// Remove auto p from Contact Form 7 shortcode output
if ( ! function_exists( 'ainext_remove_wpcf7_extra_p' ) ) {
	function ainext_remove_wpcf7_extra_p() {
		return false;
	}
}
add_filter('wpcf7_autop_or_not', 'ainext_remove_wpcf7_extra_p');