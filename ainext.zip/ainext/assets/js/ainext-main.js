(function($){
    'use strict';
	jQuery(document).on('ready', function () {

		$(window).on('scroll',function() {
			if ($(this).scrollTop() > 100){
				$('.navbar').addClass("sticky");
			}
			else{
				$('.navbar').removeClass("sticky");
			}
		});

		$('.popular-tag a').on('click', function(e) {
            e.preventDefault();
            const tagPrompt = $(this).attr('data-tag-prompt');
            $('#an_prompt').val(tagPrompt);
			const generateButton = $('#generateButton');
			generateButton.prop('disabled', false);
        });

		$(window).on('scroll',function() {
			if ($(this).scrollTop() > 50){
				$('.mb-nav').addClass("sticky");
			}
			else{
				$('.mb-nav').removeClass("sticky");
			}
		});

		// Disable the button initially if the input field is blank
		if ($('#an_prompt').val() === '') {
			$('#generateButton').prop('disabled', true);
		}
		if ($('#cn_prompt').val() === '') {
			$('#CgenerateButton').prop('disabled', true);
		}

		// Add an event listener to the input field to check its value
		$('#an_prompt').on('input', function() {
			if ($(this).val() === '') {
				$('#generateButton').prop('disabled', true);
			} else {
				$('#generateButton').prop('disabled', false);
			}
		});
		$('#cn_prompt').on('input', function() {
			if ($(this).val() === '') {
				$('#CgenerateButton').prop('disabled', true);
			} else {
				$('#CgenerateButton').prop('disabled', false);
			}
		});

		// Product +/-
		$(".plus-btn").on('click', function() {
			var  input = $(this).prev('input.qty');
			var val = parseInt(input.val());
			var step = input.attr('step');
			step = 'undefined' !== typeof(step) ? parseInt(step) : 1;
			input.val( val + step ).change();
		});

		$(".minus-btn").on('click', function() {
			var input = $(this).next('input.qty');
			var val = parseInt(input.val());
			var step = input.attr('step');
			step = 'undefined' !== typeof(step) ? parseInt(step) : 1;
			if (val > 0) {
				input.val( val - step ).change();
			}
		});

		// hover btn
		$(function() {
			$('.main-btn')
			.on('mouseenter', function(e) {
				var parentOffset = $(this).offset(),
				relX = e.pageX - parentOffset.left,
				relY = e.pageY - parentOffset.top;
				$(this).find('span').css({top:relY, left:relX})
			})
			.on('mouseout', function(e) {
				var parentOffset = $(this).offset(),
				relX = e.pageX - parentOffset.left,
				relY = e.pageY - parentOffset.top;
				$(this).find('span').css({top:relY, left:relX})
			});
		});

		$('.play').click(function(){ 
			$(this).addClass('on').siblings().removeClass('on')
		})

		  // Mobile Menu
		  $('.menu li.menu-item-has-children>a').on('click', function(){
			$(this).removeAttr('href');
			var element = $(this).parent('li');
			if (element.hasClass('open')) {
				element.removeClass('open');
				element.find('li').removeClass('open');
				element.find('ul').slideUp();
			}
			else {
				element.addClass('open');
				element.children('ul').slideDown();
				element.siblings('li').children('ul').slideUp();
				element.siblings('li').removeClass('open');
				element.siblings('li').find('li').removeClass('open');
				element.siblings('li').find('ul').slideUp();
			}
        });	
        $('.menu>ul>li.menu-item-has-children>a').append('<span class="holder"></span>');

		// Text counter effect
		function visible($element) {
			if (!$element || $element.length === 0) {
				return false;
			}
			
			var $w = jQuery(window),
				viewTop = $w.scrollTop(),
				viewBottom = viewTop + $w.height(),
				_top = $element.offset().top,
				_bottom = _top + $element.height(),
				compareTop = true ? _bottom : _top,
				compareBottom = true ? _top : _bottom;

			return compareBottom <= viewBottom && compareTop >= viewTop && $element.is(':visible');
		}

		$(window).scroll(function () {
			var $countDigits = $('.count-digit');

			if (visible($countDigits)) {
				if ($countDigits.hasClass('counter-loaded')) return;

				$countDigits.addClass('counter-loaded');
				$countDigits.each(function () {
					var $this = $(this);
					jQuery({ Counter: 0 }).animate({ Counter: $this.text() }, {
						duration: 5000,
						easing: 'swing',
						step: function () {
							$this.text(Math.ceil(this.Counter));
						}
					});
				});
			}
		});
	});
	
	$( window ).on( 'elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/widget', function( $scope ) {

		// Portfolio filtering
		$('.item-list').click(function(){ 
			const value = $(this).attr('data-filter');
			if (value == 'all'){ 
				$('.item-box').show('1000'); 
			} 
			else{
				$('.item-box').not('.' +value).hide('1000'); 
				$('.item-box').filter('.' +value).show('1000');
			}
		})

		// atrial slider
		$('.article-content').owlCarousel({
			dots: true,
			nav: false,
			loop: true,
			margin: 30,
			autoplay: false,
			autoplayHoverPause: false,
			responsive: {
				0: {
					items: 1
				},
				576: {
					items: 1
				},
				768: {
					items: 2
				},
				992: {
					items: 1
				},
				1200: {
					items: 2
				}
			}
		});

		// team slides
		$('.image-courser').owlCarousel({
			nav: true,
			loop: true,
			dots: false,
			margin: 30,
			autoplay: false,
			autoplayHoverPause: true,
			navText: [
				"<i class='fi fi-tr-angle-small-left'></i>",
				"<i class='fi fi-tr-angle-small-right'></i>"
			],
			responsive: {
				0: {
					items: 1
				},
				576: {
					items: 2
				},
				768: {
					items: 2
				},
				992: {
					items: 3
				},
				1200: {
					items: 3
				}
			}
		});

		// testimonial Slides
		$('.testimonial-content').owlCarousel({
			nav: true,
			animateOut: 'fadeOut',
			loop: true,
			dots: false,
			margin: 30,
			autoplay: false,
			autoplayHoverPause: true,
			navText: [
				"<i class='fi fi-tr-arrow-left'></i>",
				"<i class='fi fi-tr-arrow-right'></i>"
			],
			responsive: {
				0: {
					items: 1
				},
				576: {
					items: 1
				},
				768: {
					items: 1
				},
				992: {
					items: 1
				},
				1200: {
					items: 1
				}
			}
		});

		// insta slider
		$('.ins-gallery').owlCarousel({
			nav: false,
			dots: false,
			loop: true,
			autoplay: true,
			autoplayHoverPause: true,
			autoplayTimeout:1000,
			responsive: {
				0: {
					items: 3
				},
				576: {
					items: 2
				},
				768: {
					items: 5
				},
				992: {
					items: 6
				},
				1200: {
					items: 10
				}
			}
		});

		// Aos Animation
		AOS.init();

		// Popup Image
		$('.popup-btn').magnificPopup({
			type: 'image',
			gallery:{
				enabled:true
			}
		});

	})
	});//elementor active  

	// ToptoBottom Button
	let calcScrollValue = () => {
		let scrollProgress = document.getElementById("progress");
		let progressValue = document.getElementById("progress-value");
		let pos = document.documentElement.scrollTop;
		let calcHeight =
		  document.documentElement.scrollHeight -
		  document.documentElement.clientHeight;
		let scrollValue = Math.round((pos * 100) / calcHeight);
		if (pos > 100) {
		  scrollProgress.style.display = "grid";
		} else {
		  scrollProgress.style.display = "none";
		}
		scrollProgress.addEventListener("click", () => {
		  document.documentElement.scrollTop = 0;
		});
		scrollProgress.style.background = `conic-gradient(#7f00ff ${scrollValue}%, #9094a6 ${scrollValue}%)`;
	  };
	  
	  window.onscroll = calcScrollValue;
	  window.onload = calcScrollValue;
		
})(jQuery);

// Offcanvas Responsive Menu
const list = document.querySelectorAll('.responsive-menu');
function accordion(e) {
    e.stopPropagation(); 
    if(this.classList.contains('current-menu-parent')){
        this.classList.remove('current-menu-parent');
    }
    else if(this.parentElement.parentElement.classList.contains('current-menu-parent')){
        this.classList.add('current-menu-parent');
    }
    else {
        for(i=0; i < list.length; i++){
            list[i].classList.remove('current-menu-parent');
        }
        this.classList.add('current-menu-parent');
    }
}
for(i = 0; i < list.length; i++ ){
    list[i].addEventListener('click', accordion);
}
