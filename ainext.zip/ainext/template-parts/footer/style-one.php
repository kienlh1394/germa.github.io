<?php global $ainext_opt;
/**
 * 	The template for displaying the footer
 * 	@package ainext
 */

$copyright_text     = isset( $ainext_opt['copyright_text']) ? $ainext_opt['copyright_text'] : '';
?>

<?php if ( is_active_sidebar( 'footer_widgets' ) ){
    $footer_padding = "";
}else {
    $footer_padding = "foot-p-top";
} ?>

<footer class="footer-area <?php echo esc_attr($footer_padding); ?>">
    <div class="container">
        <?php if ( is_active_sidebar( 'footer_widgets' ) ): ?>
            <div class="footer-top-area pt-100">
                <div class="row">
                    <?php if ( is_active_sidebar( 'footer_widgets') ) : ?>
                        <?php dynamic_sidebar( 'footer_widgets' ); ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="pr-line"></div>

        <div class="footer-bottom-area <?php echo esc_attr($footer_padding); ?>">
            <?php if( $copyright_text != '') : ?>
                <p><?php echo wp_kses_post( $copyright_text ); ?></p>
            <?php else: ?>
                <p><?php esc_html_e( 'AiNext is Proudly Powered by AlHikmahSoft', 'ainext' ); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="lines">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
</footer>