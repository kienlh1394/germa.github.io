<?php global $ainext_opt;
/**
 * @package AiNext
 */

if( isset( $ainext_opt['ainext_blog_sidebar'] ) ) {
    if( $ainext_opt['ainext_blog_sidebar'] == 'ainext_without_sidebar' ) :
        $thumb_size = 'full';
    else:
        $thumb_size = 'ainext_standard_card';
    endif;
} else {
    $thumb_size = 'ainext_standard_card';
}

$is_post_meta   = isset( $ainext_opt['is_post_meta']) ? $ainext_opt['is_post_meta'] : false;
$categories     = get_the_category();
$blog_grid      = !empty($ainext_opt['ainext_blog_grid']) ? $ainext_opt['ainext_blog_grid'] : 'col-lg-12 col-md-12';
?>

<div <?php post_class($blog_grid); ?>>
    <div class="item">
        <?php if( has_post_thumbnail() ) { ?>
            <img src="<?php the_post_thumbnail_url( $thumb_size ) ?>" alt="<?php the_title_attribute(); ?>">
            <div class="pop-content">
            <?php }else { ?>
                <div class="post-content no-image">
            <?php } ?>

            <?php if( get_the_title() != '' ) : ?>
                    <h3><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h3>
            <?php endif; ?>

            <?php if( $is_post_meta  == false ) { ?>
                <ul>
                    <li>
                        <?php echo esc_html(get_the_date()) ?>
                    </li>
                    <li>
                        <?php comments_number(); ?>
                    </li>
                </ul>
            <?php } ?>
        </div>
        
        <div class="go-corner" href="<?php the_permalink() ?>">
            <div class="go-arrow">
                <i class="ri-arrow-right-up-line"></i>
            </div>
        </div>
    </div>
</div>