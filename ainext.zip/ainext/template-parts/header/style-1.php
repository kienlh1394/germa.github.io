<?php global $ainext_opt;
/**
 * @package AiNext
*/

$header_btn                 = !empty($ainext_opt['header_btn']) ? $ainext_opt['header_btn'] : '';
$enable_header_btn 		    = !empty($ainext_opt['enable_header_btn']) ? $ainext_opt['enable_header_btn'] : '';
$header_btn_icon 		    = !empty($ainext_opt['header_btn_icon']) ? $ainext_opt['header_btn_icon'] : '';
$header_btn_link_type       = !empty($ainext_opt['header_btn_link_type']) ? $ainext_opt['header_btn_link_type'] : '';
$header_btn_link_external	= !empty($ainext_opt['header_btn_link_external']) ? $ainext_opt['header_btn_link_external'] : '';
$header_btn_internal 		= !empty($ainext_opt['header_btn_internal']) ? $ainext_opt['header_btn_internal'] : '';

if( function_exists('acf_add_options_page') && get_field( 'choose_nav_width' ) != '' ) {
    $nav_width          = get_field( 'choose_nav_width' );
} else {
    $nav_width          = 'container-fluid';
}
?>

<!-- Header -->
<nav class="navbar navbar-expand-lg mb-nav" id="navbar">
    <div class="<?php echo esc_attr($nav_width); ?>">
        <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
            <?php ainext_main_logo(); ?>
        </a>
        <a class="navbar-toggler text-decoration-none" data-bs-toggle="offcanvas" href="#navbarOffcanvas" role="button" aria-controls="navbarOffcanvas">
            <span class="burger-menu">
                <span class="top-bar"></span>
                <span class="middle-bar"></span>
                <span class="bottom-bar"></span>
            </span>
        </a>
        <div class="collapse navbar-collapse">
            <?php 
            $primary_nav_arg = [
                'menu'            => 'primary',
                'theme_location'  => 'primary',
                'container'       => null,
                'menu_class'      => 'navbar-nav',
                'depth'           => 3,
                'walker'          => new AiNext_Bootstrap_Navwalker(),
                'fallback_cb'     => 'AiNext_Bootstrap_Navwalker::fallback',
            ];

            if ( has_nav_menu('primary') ) :
                wp_nav_menu( $primary_nav_arg );
            endif;
            ?>

            <?php if( $enable_header_btn == true && $header_btn != '') : ?>
                <div class="nav-btn">
                <?php if( $header_btn != '' ) : ?>
                    <?php if( $header_btn_link_type == 'external_link' ): ?>
                        <a href="<?php echo esc_url( $header_btn_link_external ); ?>" class="default-btn"> <?php echo esc_html( $header_btn ); ?> <i class="<?php echo esc_attr($header_btn_icon); ?>"></i></a>
                    <?php elseif( $header_btn_link_type == 'internal_link' ): ?>
                        <a href="<?php echo esc_url( home_url( $header_btn_internal ) ); ?>" class="default-btn"> <?php echo esc_html( $header_btn ); ?> <i class="<?php echo esc_attr($header_btn_icon); ?>"></i></a>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>
<!-- Header end -->

<!-- Responsive Navbar Area -->
<div class="responsive-navbar offcanvas offcanvas-end border-0" data-bs-backdrop="static" tabindex="-1" id="navbarOffcanvas">
    <div class="offcanvas-header">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo d-inline-block">
            <?php ainext_mobile_logo(); ?>
        </a>
        <button type="button" class="close-btn bg-transparent position-relative lh-1 p-0 border-0" data-bs-dismiss="offcanvas" aria-label="Close">
            <i class="ri-close-line"></i>
        </button>
    </div>
    <div class="offcanvas-body">
        <?php
        $primary_nav_arg = [
            'menu'            => 'primary',
            'theme_location'  => 'primary',
            'container'       => null,
            'depth'           => 3,
        ];

        if(has_nav_menu('primary')){
            wp_nav_menu($primary_nav_arg);
        }
        ?>
        <?php if( $enable_header_btn == true && $header_btn != '') : ?>
            <div class="others-option d-md-flex align-items-center">
                <div class="option-item">
                    <?php if( $header_btn != '' ) : ?>
                        <?php if( $header_btn_link_type == 'external_link' ): ?>
                            <a href="<?php echo esc_url( $header_btn_link_external ); ?>" class="default-btn"> <?php echo esc_html( $header_btn ); ?> <i class="<?php echo esc_attr($header_btn_icon); ?>"></i></a>
                        <?php elseif( $header_btn_link_type == 'internal_link' ): ?>
                            <a href="<?php echo esc_url( home_url( $header_btn_internal ) ); ?>" class="default-btn"> <?php echo esc_html( $header_btn ); ?> <i class="<?php echo esc_attr($header_btn_icon); ?>"></i></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- End Responsive Navbar Area -->

